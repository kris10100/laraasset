See http://docs.snipeitapp.com/installation/server/docker.html for Docker information
