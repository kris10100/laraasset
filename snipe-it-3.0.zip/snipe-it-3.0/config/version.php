<?php
return array (
  'app_version' => 'v3.0',
  'hash_version' => 'v3.0-ebc74a65',
);
